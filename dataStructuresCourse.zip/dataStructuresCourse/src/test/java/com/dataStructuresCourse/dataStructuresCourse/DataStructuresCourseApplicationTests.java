package com.dataStructuresCourse.dataStructuresCourse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataStructuresCourseApplicationTests {

	@Test
	void contextLoads() {
	}

}
